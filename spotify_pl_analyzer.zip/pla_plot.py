import numpy as np
import pandas
import plotly
import plotly.plotly as py
import plotly.graph_objs as go
plotly.tools.set_credentials_file(username='kaancet', api_key='U399IWwsVmePOzBGwRST')

def pl2plot(df_list=[]):
    data=[]
    hex_color=['0','1','2','3','4','5','6','7','A','B','C','D','E','F']
    color_list = ["#"+''.join([np.random.choice(hex_color) for j in range(6)])for i in range(len(df_list))]
    for i,playlist in enumerate(df_list):
        trace=go.Scatter3d(
            x=playlist[0]['tempo'],
            y=playlist[0]['band_diff'],
            z=playlist[0]['spec_flat'],
            text=playlist[0]['Song'],
            mode='markers',
            marker=dict(
                size=8,
                color=color_list[i]
                ),
            opacity=0.9,
            name=playlist[1]
        )
        data.append(trace)
    return data

def track2plot(track_list=[],color_in='#af2427'):
    data=[]
    for track in track_list:
        track_trace=go.Scatter3d(
            x=[track['tempo']],
            y=[track['band_diff']],
            z=[track['spec_flat']],
            text=track['Song'],
            mode='markers',
            marker=dict(
                size=8,
                color=color_in,
                line=dict(
                    color='#27af24',
                    width=0.5
                ),
            opacity=0.9,
            ),
            name=track['Song']
        )
        data.append(track_trace)
    return data

def plot_layout():
    # layout of the figure
    layout=go.Layout(
        scene = dict(
        xaxis=dict(
            title='Tempo',
            titlefont=dict(
                family='Helvetica',
                size=18,
                color='#585958'
            ),
            #range=[]
        ),
        yaxis=dict(
            title='Bandwidth Difference',
            titlefont=dict(
                family='Helvetica',
                size=18,
                color='#585958'
            ),
            #range=[]
        ),
        zaxis=dict(
            title='Spectral Flatness',
            titlefont=dict(
                family='Helvetica',
                size=18,
                color='#585958'
            ),
            #range=[]
        )),
        autosize=False,
        width=800,
        height=800,
    )
    return layout