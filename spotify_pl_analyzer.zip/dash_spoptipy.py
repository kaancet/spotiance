import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import pla_functions as pla
import pla_plot as plp
print('Libraries imported')

# spotify authorize
token=pla.authSpotify()

# get the playlist and a track
# playlist=pla.get_playlist('kaan3','Puis danse',token)
# temp=playlist[0][30:32]
# temp_playlist=(temp,'deneme')
# track=pla.get_song('Bon Voyage Organisation','Love Soup',token)

# #analyze the playlist and the track
# pl_analyzed=pla.analyze_playlist(temp_playlist)
# tr_analyzed=pla.analyze_track(track)

# pl_data=plp.pl2plot([pl_analyzed])
# track_data=plp.track2plot([tr_analyzed])
fig_lay=plp.plot_layout()

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app=dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.config.requests_pathname_prefix = app.config.routes_pathname_prefix.split('/')[-1]
app.css.append_css({"external_url": "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"})

app.layout = html.Div(
[
    html.Div(
        [
            # Graph div
            html.Div(
                [
                    dcc.Graph(
                        id='example-graph',
                        figure={
                            'data': [],
                            'layout':fig_lay
                        },
                    ), 
                ],
                className='col-md-6 col-lg-6'
            ),
            # Buttons and selection div
            html.Div(
                [
                    # Title and image row
                    html.Div(
                        [
                            html.H1(
                                children='Spotify Playlist Analyzer',
                                style={
                                    'color':'#18D860',
                                    'font-size':'%300'
                                },
                                className='col-md-12 col-lg-12'
                            ),
                            # html.Img(
                            #     src='https://img2.wikia.nocookie.net/__cb20131114014914/elderscrolls/images/2/24/Michael_Scott_Prison.png',
                            #     className='col-lg-1'
                            # ),
                        ],
                        className='row'
                    ),
                    # User input and button row
                    html.Div(
                        [
                            dcc.Input(
                                placeholder='Search user',
                                id='user-select',
                                value='',
                                type='text',
                                className='col-md-5 col-lg-5'
                            ),
                            html.Button(
                                id='get-user-button',
                                children='Get Playlists',
                                className='col-md-2 col-lg-2'
                            )
                        ],
                        className='row'
                    ),
                    # Playlist select row
                    html.Div(
                        [
                            dcc.Dropdown(
                                id='pl-drop',
                                multi=True,
                            ),
                            
                        ],
                    ),

                    html.Button(
                                id='get-pl-button',
                                children='Get Tracks',
                    ),
                    #checklist row
                    html.Div(
                        [
                            dcc.Checklist(
                                id='selected-pls',
                                options=[],
                                values=[],
                                labelStyle={'display': 'inline-block'}
                            ),
                        ]
                    ),
                    # Put track selection here
                    html.Div(
                        [
                            dcc.Input(
                                placeholder='Artist-Song',
                                id='song-search',
                                value='',
                                type='text',
                                className='col-md-5 col-lg-5'
                            ),
                            html.Button(
                                id='get-track-button',
                                children='Serch Track',
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            dcc.Checklist(
                                id='selected-tracks',
                                options=[],
                                values=[],
                                labelStyle={'display': 'inline-block'}
                            ),
                        ]
                    ),
                    html.Button(
                        id='update-graph-button',
                        children='Graph'
                    ),
                    html.Label(
                        id='radio-select',
                        children='selected pls'
                    )
                ],
                className='col-md-6 col-lg-6'
            )
        ],
        className='row'
    )
],
className='container-fluid'
)

# Update the dropdown by getting playlist of the searched username
@app.callback(
    Output('pl-drop','options'),
    [Input('get-user-button','n_clicks')],
    [State('user-select','value')]
)
def update_pl_dropdown(n_clicks,input_value):
    try:
        sp=pla.spotipy.Spotify(auth=token) 
    except:
        token=pla.authSpotify()
        sp=pla.spotipy.Spotify(auth=token)
        pass
    playlists=sp.user_playlists(input_value)
    drop_list=[]
    for item in playlists['items']:
        temp_dict={'label':item.get('name'),'value':item.get('name')}
        drop_list.append(temp_dict)
    return drop_list

# Update the checklist with selected playlists from the dropdown
@app.callback(
    Output('selected-pls','options'),
    [Input('get-pl-button','n_clicks')],
    [State('user-select','value'),
    State('pl-drop','value'),
    State('selected-pls','options')]
)
def get_playlists(n_clicks,value1,value2,pl_checklist):
    #value1->user
    #value2->playlist list
    for pl in value2:
        temp_playlist,no_prew=pla.get_playlist(value1,pl,token)
        playlist=pla.analyze_playlist(temp_playlist)
        lbl='{} {}/{}'.format(playlist[1],playlist[0].shape[0]-no_prew,playlist[0].shape[0])
        temp_dict={'label':lbl,'value':playlist[0].to_json()}
        pl_checklist.append(temp_dict)
    return pl_checklist

# Search a track and update the track checklist
@app.callback(
    Output('selected-tracks','options'),
    [Input('get-track-button','n_clicks')],
    [State('song-search','value'),
    State('selected-tracks','options')],
)
def get_track(n_clicks,search_string,track_checklist):
    temp_list=search_string.split('-')
    temp_track=pla.get_song(temp_list[0],temp_list[1],token=token)
    
    analyzed_track=pla.analyze_track(temp_track)
    lbl='{}-{}'.format(analyzed_track[0],analyzed_track[1])
    temp_dict={'label':lbl,'value':analyzed_track.to_json()}
    track_checklist.append(temp_dict)
    return

#Update the graph with selected playlists and tracks in the checklist
@app.callback(
    Output('radio-select','children'),
    [Input('update-graph-button','n_clicks')],
    [State('selected-pls','values'),
    State('selected-tracks','values')]
)
def update_graph(n_clicks,pl_list,track_list):
    return 'Selected pls are {}'.format(pl_list)


if __name__ == '__main__':
    app.run_server()